import PySimpleGUI as sg

layout = [
    [sg.Input(size=(10,1), key='expressao', justification='right', readonly=True)],
    [sg.Button('1'), sg.Button('2'), sg.Button('3'), sg.Button('+')],
    [sg.Button('4'), sg.Button('5'), sg.Button('6'), sg.Button('-')],
    [sg.Button('7'), sg.Button('8'), sg.Button('9'), sg.Button('*')],
    [sg.Button('0'), sg.Button('.'), sg.Button('c'), sg.Button('/')],
    [sg.Button('Calcular')]
]

window = sg.Window('Calculadora', layout)

while True:
    event, values = window.read()

    if event == sg.WINDOW_CLOSED:
        break

    if event == 'Calcular':
        expressao = values['expressao']

        try:
            resultado = eval(expressao)
            sg.Popup(f'O resultado é: {resultado}')
        except:
            sg.Popup('Expressão inválida!')

    elif event in '0123456789.+-*/':
        window['expressao'].update(values['expressao'] + event)

    if event == 'c':
      Clear = ' '
      window[windows]. update(Clear)

 

window.close()